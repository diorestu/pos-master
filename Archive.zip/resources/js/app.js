import "@tabler/core/src/js/tabler.js";

import "./bootstrap";
